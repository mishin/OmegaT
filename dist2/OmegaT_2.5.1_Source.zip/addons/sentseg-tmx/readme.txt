TMX Sentence Segmenter 1.0 ReadMe file

This tool allows to re-segment old TMX files (created by OmegaT)
in a sentence-segmentation mode.

To run from a terminal or DOS window, change to this directory
and type
  java -jar sentseg-tmx.jar

----------------------------------------------------------------------

Verison 1.0: Initial release

Verison 1.1: Updated to work using OmegaT 1.6.0 RC7+ core classes
